-- create the databases
CREATE DATABASE IF NOT EXISTS impostosolidario;
USE impostosolidario;