-- create the databases
CREATE DATABASE IF NOT EXISTS impostosolidario_2;
USE impostosolidario_2;