#!/bin/bash
# docker exec -d laravel_teste_server composer install
docker exec -d impostosolidario_server chmod -R 777 storage